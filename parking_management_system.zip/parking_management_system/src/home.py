from tkinter import *
from wayin import wayinGUI
from wayout import wayoutGUI
import mysql.connector
from itertools import cycle


images = ["logout.png",
"parking.png",
"parking_icon.png",
"way_in.png",
"way_out.png"]

photos = cycle(PhotoImage(file=image) for image in images)

def slideShow():
  img = next(photos)
  displayCanvas.config(image=img)
  homeframe.after(500, slideShow) # 0.05 seconds

def wayout():
    wayoutGUI()

def wayin():
    wayinGUI()

def homeGUI():
    flag=242
    global homeframe
    homeframe=Toplevel()
    sw = homeframe.winfo_screenwidth()
    sh = homeframe.winfo_screenheight()
    xc = int((sw / 2) - 450)
    yc = int((sh / 2) - 350)
    homeframe.geometry("900x700+{0}+{1}".format(xc, yc))
    homeframe.title("home")
    photo3= PhotoImage(file="parking_icon.png")
    homeframe.iconphoto(False, photo3)
    homeframe.resizable(False,False)




    photo5 = PhotoImage(file="way_in.png")
    wayinbutton = Button(homeframe,command=wayin)
    wayinbutton.config(font=("Time New Roman", 15), image=photo5)
    wayinbutton.place(x=50, y=500)

    photo6 = PhotoImage(file="way_out.png")
    wayoutbutton = Button(homeframe,command=wayout)
    wayoutbutton.config(font=("Time New Roman", 15), image=photo6)
    wayoutbutton.place(x=490, y=500)

    global displayCanvas
    #root.geometry('%dx%d' % (640, 480))
    displayCanvas = Label(homeframe)
    displayCanvas.pack()
    slideShow()

    homeframe.mainloop()


def home():
    homeGUI()
