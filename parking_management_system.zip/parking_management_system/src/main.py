import tkinter as tk

import mysql.connector
from splashscreen import splashGUI
from home import *


def loginGUI():
    global userentry,passwordentry,loginframe
    loginframe = Tk()
    sw = loginframe.winfo_screenwidth()
    sh = loginframe.winfo_screenheight()
    xc = int((sw / 2) - 300)
    yc = int((sh / 2) - 300)
    loginframe.geometry("600x600+{0}+{1}".format(xc,yc))
    loginframe.title("PARKING MANAGEMENT SYSTEM")
    loginframe.resizable(False, False)
    photo = PhotoImage(file="parking_icon.png")
    loginframe.iconphoto(False, photo)
    canvas = Canvas(loginframe, width=600, height=250)
    canvas.pack()
    photo1 = PhotoImage(file='parking.png')
    canvas.create_image(230, 35, anchor=NW, image=photo1)
    Label(loginframe, image=photo1)
    l = Label(loginframe, text="Parking Mangement System", width=50)
    l.config(font=("Time New Roman", 30))
    l.pack()

    userlable = Label(loginframe, text="Username")
    userlable.config(font=("Time New Roman", 15))
    userlable.place(x=130, y=350)

    userentry = Entry(loginframe)
    userentry.config(font=("Time New Roman", 15))
    userentry.place(x=230, y=350)

    passwordlabel = Label(loginframe, text="Password")
    passwordlabel.config(font=("Time New Roman", 15))
    passwordlabel.place(x=130, y=400)

    passwordentry = Entry(loginframe)
    passwordentry.config(font=("Time New Roman", 15), show="*")
    passwordentry.place(x=230, y=400)
    loginbutton = Button(text="Login", command=compare)
    loginbutton.config(font=("Time New Roman", 15))
    loginbutton.place(x=270, y=450)
    loginframe.mainloop()


def compare():
    flag=0
    user = "eff4ecedccccccccf4c4ced"
    passwd = "4r4ecefcefffffffffffff44e"
    if userentry.get() == "" or passwordentry.get() == "":
        tk.messagebox.showinfo(title="Error", message="Please enter username password")
        flag=1
    x = list()
    db = mysql.connector.connect(host="localhost", user="root", passwd="root", database="pms")
    dbcursor = db.cursor()

    dbcursor.execute("SELECT * FROM login WHERE USERNAME='{0}' ".format(userentry.get()))
    for i in dbcursor:
        user=i[0]
        passwd=i[1]
        print(user,passwd)
        print(i)
    if userentry.get()==user and passwordentry.get()==passwd:
        global loginframe
        loginframe.withdraw()
        homeGUI()
    else:
        if flag==1:
            pass
        else:
            tk.messagebox.showinfo(title="Error",message="Please enter correct username password")


if __name__ == '__main__':
    splashGUI()
    loginGUI()






