import datetime
import mysql.connector
def payment(vehicleno):
    intime = 0
    outtime = datetime.datetime.now().replace(microsecond=0,second=0)
    filterouttime = str(outtime).replace("-", " ").replace(":", " ").split(" ")
    db = mysql.connector.connect(host="localhost", user="root", passwd="root", database="pms")
    dbcursor = db.cursor()
    dbcursor.execute("select intime from currentparking where vehicleno='{0}'".format(vehicleno))
    for i in dbcursor:
        intime = i[0]

    filterintime = str(intime).replace("-", " ").replace(":", " ").split(" ")
    c=0
    for i in filterouttime:
        if c == 3:
            filterouttime[c]=int(i)
        elif c == 2:
            filterouttime[c] = int(i)
        else:
            filterouttime[c] = int(i)


        c=c+1
    c = 0
    for i in filterintime:
        filterintime[c] = int(i)
        c = c + 1
    diffrence=[]
    for i,j in zip(filterouttime,filterintime):
        diffrence.append(abs(i-j))
    print(diffrence)
    parkingRS=5
    rs=(diffrence[3]*parkingRS)+(diffrence[2]*24)*parkingRS
    print(rs)
    print(filterouttime)
    print(filterintime)
    return rs

'''if __name__ == '__main__':
    payment("mh02")'''