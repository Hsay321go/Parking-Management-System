from tkinter import *

from itertools import cycle

images = ["S1.png",
          "S2.png",
          "S3.png",
          "S4.png",
          "S5.png",
          "S6.png",
          "S7.png",
          "S8.png",
          "S9.png",
          "S10.png",
          "S11.png",
          "S12.png",
          "S13.png",
          "S14.png",
          "S15.png",
          "S16.png",
          "S17.png",
          "S18.png",
          "S19.png",
          "S20.png",
          "S21.png",
          "S22.png",
          "S23.png",
          "S24.png",
          "S25.png",
          "S26.png",
          "S27.png"
          ]

photos = cycle(PhotoImage(file=image) for image in images)


def slideShow():
    try:
        img = next(photos)
        canvas.config(image=img)
        canvas.after(100, slideShow)
    except Exception as e:
        pass

def splashGUI():
    global canvas
    splash = Tk()
    splash.geometry("1600x900")
    canvas = Label(splash)
    canvas.pack()
    slideShow()
    splash.after(4600, splash.destroy)
    splash.wm_attributes("-alpha", 0.4)
    splash.wm_attributes("-fullscreen", True)
    splash.mainloop()
