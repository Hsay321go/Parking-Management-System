from tkinter import *
from tkinter.messagebox import *
import tkinter as tk
import mysql.connector
import datetime
import mysql
from wayinrecipt import wayinrecipt
mx=list()

def set_text(ent,text):
    ent.delete(0,END)
    ent.insert(0,text)
    return

def register():
    try:
        if vehicalnoeentry.get()=="" and drivernameentry.get()=="" and mobilenoentry.get()=="":
            tk.messagebox.showinfo(title="Error", message="please Fill all the details")
        db = mysql.connector.connect(host="localhost", user="root", passwd="root", database="pms")
        dbcursor = db.cursor()
        dbcursor.execute("insert into currentparking values('{0}','{1}',{2},'{3}','{4}')".format(vehicalnoeentry.get().upper(),drivernameentry.get(),mobilenoentry.get(),mx[-1],datetime.datetime.now().replace(microsecond=0,second=0)))
        db.commit()
        m=[]
        wayinframe.focus_force()
        wayinrecipt(vehicalnoeentry.get())
        tk.messagebox.showinfo(title="Great!!!", message="done!!!")
        set_text(vehicalnoeentry,"")
        set_text(drivernameentry,"")
        set_text(mobilenoentry,"")
        set_text(wayinframe,"")
        bicycle.deselect()
        car.deslect()
        bike.deselect()
        truck.deselect()
        wayinframe.focus_force()
    except Exception as e:
        print(e)

def wayinGUI():
    global vehicalnoeentry,drivernameentry,mobilenoentry,wayinframe,bicycle,car,bike,truck
    wayinframe=Toplevel()
    sw = wayinframe.winfo_screenwidth()
    sh = wayinframe.winfo_screenheight()
    xc = int((sw / 2) - 600)
    yc = int((sh / 2) - 250)
    wayinframe.geometry("500x500+{0}+{1}".format(xc, yc))
    photo7=PhotoImage(file="parking_icon.png")
    wayinframe.iconphoto(False, photo7)
    wayinframe.title("Wayin")
    wayinframe.resizable(False,False)

    vehicalno=Label(wayinframe,text="Car no")
    vehicalno.config(font=("Time New Roman",15))
    vehicalno.place(x=100,y=250)

    vehicalnoeentry=Entry(wayinframe)
    vehicalnoeentry.config(font=("Time New Roman", 15))
    vehicalnoeentry.place(x=180,y=250)


    drivername=Label(wayinframe,text="Driver name")
    drivername.config(font=("Time New Roman",15))
    drivername.place(x=60,y=300)

    drivernameentry = Entry(wayinframe)
    drivernameentry.config(font=("Time New Roman", 15))
    drivernameentry.place(x=180, y=300)

    mobileno = Label(wayinframe, text="Mobile no")
    mobileno.config(font=("Time New Roman", 15))
    mobileno.place(x=75, y=350)

    mobilenoentry = Entry(wayinframe)
    mobilenoentry.config(font=("Time New Roman", 15))
    mobilenoentry.place(x=180, y=350)

    price = StringVar()
    def setvalue():
        xy=price.get()
        print("hello"+xy)
        mx.append(xy)
    bicycle = Radiobutton(wayinframe, text="Bicycle", variable=price,command=setvalue, value="bicycle")
    bike = Radiobutton(wayinframe, text="Bike", variable=price,command=setvalue, value="bike")
    car=Radiobutton(wayinframe,text="Car",variable=price,command=setvalue,value="car")
    truck=Radiobutton(wayinframe,text="Truck",variable=price,command=setvalue,value="truck")
    bicycle.config(font=("Time New Roman", 15))
    bike.config(font=("Time New Roman", 15))
    car.config(font=("Time New Roman", 15))
    truck.config(font=("Time New Roman", 15))
    bicycle.place(x=60,y=400)
    bike.place(x=160, y=400)
    car.place(x=260, y=400)
    truck.place(x=360, y=400)
    #bicycle.select()


    registerbutton = Button(wayinframe, text="register",command=register)
    registerbutton.config(font=("Time New Roman", 15),bg="LightGreen")
    registerbutton.place(x=200, y=450)

    wayinframe.mainloop()
#wayinGUI()