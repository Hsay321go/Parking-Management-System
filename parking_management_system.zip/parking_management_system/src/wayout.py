from tkinter import *
import mysql;
import datetime
from payment import payment
import tkinter as tk
from wayoutrecipt import wayoutrecipt
from tkinter.messagebox import *
import mysql.connector
db = mysql.connector.connect(host="localhost", user="root", passwd="root", database="pms")

def set_text(ent,text):
    try:
        ent.delete(0,'end')
        ent.insert(0,text)
    except Exception as e:
        print(e)
    return

def up():
    dbcursor = db.cursor()
    dbcursor.execute("select * from currentparking")
    x = 1
    for i in dbcursor:
        display.insert(x, i[0]+" "+i[1]+" "+i[3]+" "+i[4])
        x = x + 1
def checkout():
    dbcursor=db.cursor()
    dbcursor1 = db.cursor()
    dbcursor2=db.cursor()
    if vehicalnoeentry.get() == "" and drivernameentry.get() == "" and mobilenoentry.get() == "":
        tk.messagebox.showinfo(title="Error", message="please Fill all the details")
    print(vehicalnoeentry.get())
    dbcursor.execute("select * from currentparking where vehicleno='{0}'".format(vehicalnoeentry.get()))
    rs = payment(vehicalnoeentry.get())
    for i in dbcursor:
        dbcursor1.execute("insert into parkingrecord values('{0}','{1}',{2},'{3}','{4}','{5}',{6})".format(i[0],i[1],i[2],i[3],i[4],datetime.datetime.now().replace(microsecond=0),rs))
        db.commit()

    dbcursor2.execute("delete from currentparking where vehicleno='{0}'".format(vehicalnoeentry.get()))
    db.commit()

    wayoutrecipt(vehicalnoeentry.get())
    tk.messagebox.showinfo(title="Great!!!!.", message="Checkout Done!! Please pay {0} Rupee".format(rs))
    set_text(vehicalnoeentry, "")
    set_text(drivernameentry, "")
    set_text(mobilenoentry, "")
    set_text(paymententry, "")
    set_text(wayoutframe, "")
    bicycle.deselect()
    car.deselect()
    bike.deselect()
    truck.deselect()
    display.delete(0,'end')
    up()
    wayoutframe.focus_force()
def cheak():
    index=display.curselection()[0]
    seltext = display.get(index)
    vehi=seltext.split(" ")[0]
    print(vehi)
    set_text(paymententry, payment(vehi))
    dbcursor = db.cursor()
    sql = "select * from currentparking where vehicleno='{0}'".format(vehi)
    print(sql)
    dbcursor.execute(sql)
    print(dbcursor.rowcount, vehicalnoeentry.get())
    for i in dbcursor:
        print(i)
        set_text(vehicalnoeentry,vehi)
        set_text(drivernameentry, i[1])
        set_text(mobilenoentry, i[2])
        if i[3] == "bicycle":
            bicycle.select()
        elif i[3] == "car":
            car.select()
        elif i[3] == "truck":
            truck.select()
        elif i[3] == "bike":
            bike.select()
def wayoutGUI():
    global vehicalnoeentry, drivernameentry, mobilenoentry, car, truck, bicycle, bike, wayoutframe,display,paymententry
    wayoutframe = Toplevel()
    sw = wayoutframe.winfo_screenwidth()
    sh = wayoutframe.winfo_screenheight()
    xc = int((sw / 2) + 200)
    yc = int((sh / 2) - 350)
    wayoutframe.geometry("500x700+{0}+{1}".format(xc, yc))
    photo8 = PhotoImage(file="parking_icon.png")
    wayoutframe.iconphoto(False, photo8)
    wayoutframe.title("Wayout")
    wayoutframe.resizable(False, False)


    display=Listbox(wayoutframe,width=68, height=19)
    display.config(font=("Time New Roman", 10),selectmode="SINGLE")
    up()
    display.place(x=10,y=10)

    vehicalno = Label(wayoutframe, text="Car no")
    vehicalno.config(font=("Time New Roman", 15))
    vehicalno.place(x=50, y=350)

    vehicalnoeentry = Entry(wayoutframe)
    vehicalnoeentry.config(font=("Time New Roman", 15))
    vehicalnoeentry.place(x=130, y=350)

    cheakbutton = Button(wayoutframe, text="Cheak",command=cheak)
    cheakbutton.config(font=("Time New Roman", 15), bg="LightGreen")
    cheakbutton.place(x=380, y=345)

    drivername = Label(wayoutframe, text="Driver name")
    drivername.config(font=("Time New Roman", 15))
    drivername.place(x=60, y=400)

    drivernameentry = Entry(wayoutframe)
    drivernameentry.config(font=("Time New Roman", 15))
    drivernameentry.place(x=180, y=400)

    mobileno = Label(wayoutframe, text="Mobile no")
    mobileno.config(font=("Time New Roman", 15))
    mobileno.place(x=75, y=450)

    mobilenoentry = Entry(wayoutframe)
    mobilenoentry.config(font=("Time New Roman", 15))
    mobilenoentry.place(x=180, y=450)

    prize = 0
    bicycle = Radiobutton(wayoutframe, text="Bicycle", variable="prize", value=5)
    bike = Radiobutton(wayoutframe, text="Bike", variable="prize", value=10)
    car = Radiobutton(wayoutframe, text="Car", variable="prize", value=15)
    truck = Radiobutton(wayoutframe, text="Truck", variable="prize", value=20)
    bicycle.config(font=("Time New Roman", 15))
    bike.config(font=("Time New Roman", 15))
    car.config(font=("Time New Roman", 15))
    truck.config(font=("Time New Roman", 15))
    bicycle.place(x=60, y=500)
    bike.place(x=160, y=500)
    car.place(x=260, y=500)
    truck.place(x=360, y=500)

    paymentlable=Label(wayoutframe,text="Payment")
    paymentlable.config(font=("Time New Roman", 15),fg="Green")
    paymentlable.place(x=80, y=550)

    paymententry = Entry(wayoutframe)
    paymententry.config(font=("Time New Roman", 15))
    paymententry.place(x=180, y=550)

    cheakoutbutton = Button(wayoutframe, text="Checkout", command=checkout)
    cheakoutbutton.config(font=("Time New Roman", 15))
    cheakoutbutton.place(x=200, y=650)

    wayoutframe.mainloop()

#wayoutGUI()