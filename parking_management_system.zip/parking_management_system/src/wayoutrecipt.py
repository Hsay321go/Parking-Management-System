import mysql.connector
def wayoutrecipt(vehicleno):
    try:
        f = open("E:\\pytondir\\parking_management_system\\recipt\wayout\\{0}.txt".format(vehicleno), "w");
        db = mysql.connector.connect(host="localhost", user="root", passwd="root", database="pms")
        dbcursor = db.cursor()
        dbcursor1 = db.cursor()
        dbcursor.execute("select * from parkinginfo")
        for i in dbcursor:
            f.write("*******"+i[0]+"********"+"\n")
            f.write("        "+i[2]+"\n")
            f.write("      "+i[3]+"\n")
            f.write("---------------------------\n")
        dbcursor1.execute("select * from parkingrecord where vehicleno='{0}'".format(vehicleno))
        for i in dbcursor1:
            f.write("Vehicle no:-    {0}\n".format(i[0]))
            f.write("Driver name:- {0}\n".format(i[1]))
            f.write("Contact NO:-     {0}\n".format(i[2]))
            f.write("Parking vehicle:-  {0}\n".format(i[3]))
            f.write("Intime:-{0}\n".format(i[4]))
            f.write("outtime:-{0}\n".format(i[5]))
            f.write("---------------------------\n")
            f.write("TOTAL RS:-           {0}/-\n".format(i[6]))
            f.write("---------------------------\n")
            f.write("       THANK YOU!!\n")
            f.write("---------------------------\n")
    except Exception as er:
        print(er)
#wayinrecipt("mh02")